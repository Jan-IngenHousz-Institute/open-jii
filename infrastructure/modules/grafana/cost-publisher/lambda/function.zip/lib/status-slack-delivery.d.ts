/**
 * The webhook address in the secret's text. It has to be https and carry no user name or password,
 * because `fetch` names the whole address in the error it throws for one, and that error is logged.
 * The message never quotes the secret.
 */
export declare function webhookUrlOf(secret: string | undefined): string;
/**
 * Event ids one function instance posted, oldest first and capped. The publisher can send an event
 * again and SNS can deliver one twice, so a repeat on a warm instance is skipped. A cold instance
 * starts empty, so this is best effort.
 */
export declare class PostedIds {
    private readonly limit;
    private readonly ids;
    constructor(limit: number);
    has(id: string): boolean;
    remember(id: string): void;
}
//# sourceMappingURL=status-slack-delivery.d.ts.map