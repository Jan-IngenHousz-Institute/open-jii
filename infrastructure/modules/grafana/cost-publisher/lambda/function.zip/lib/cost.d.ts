import type { CostResultByTime, CostServices, ForwarderDatum } from "./types.js";
/** The only namespace the cost publisher's role may publish into. */
export declare const COST_NAMESPACE = "OpenJII/Cost";
export declare const DAILY_COST_METRIC = "DailyCostUsd";
export declare const WEEKLY_COST_METRIC = "WeeklyCostUsd";
export declare const MONTH_TO_DATE_COST_METRIC = "MonthToDateCostUsd";
export declare const PREVIOUS_MONTH_TO_DATE_COST_METRIC = "PreviousMonthToDateCostUsd";
export declare const PREVIOUS_MONTH_COST_METRIC = "PreviousMonthCostUsd";
export declare const MONTH_FORECAST_COST_METRIC = "MonthForecastCostUsd";
export declare const PREVIOUS_MONTH_TAX_AND_FEES_METRIC = "PreviousMonthTaxAndFeesUsd";
export declare const DAILY_COST_PERCENT_OF_LIMIT_METRIC = "DailyCostPercentOfLimit";
/**
 * A day is past its limit at twice its usual day, and only when that is at least the floor above
 * it, so a service that usually costs cents does not alert for doubling. Replayed over dev's 90
 * days to 26 October 2026, AWS and Databricks together alerted about ten times, against three at a
 * $20 floor. The alerts caught EC2's September ramp here and the metrics pipeline's growth in the
 * heartbeat export's Databricks figures.
 */
export declare const SPEND_LIMIT_MULTIPLE = 2;
export declare const SPEND_LIMIT_FLOOR_USD = 10;
/** The days before yesterday whose median is a service's usual day. */
export declare const SPEND_BASELINE_DAYS = 14;
export declare const COST_METRICS: string[];
/**
 * The windows one run reports, as UTC midnights with exclusive ends, the way Cost Explorer
 * reads them. Each figure is stamped at its window's end: CloudWatch holds a point stamped a day
 * or more back for two days before it returns it, and a window that closed at midnight lands in
 * exactly one daily or weekly bucket however a dashboard aligns its periods.
 */
export interface CostWindows {
    today: Date;
    /** The latest complete ISO week, to the Monday it closed. */
    weekStart: Date;
    weekEnd: Date;
    /** The month of the latest complete day, which on the 1st is the month just ended. */
    monthStart: Date;
    nextMonthStart: Date;
    previousMonthStart: Date;
    /** The month before, to the same day of the month or its own end. */
    previousMonthToDateEnd: Date;
}
export interface CostRequest {
    TimePeriod: {
        Start: string;
        End: string;
    };
    Granularity: "DAILY" | "MONTHLY";
    Metrics: string[];
    GroupBy?: {
        Type: "DIMENSION";
        Key: "SERVICE" | "INSTANCE_TYPE";
    }[];
    Filter?: {
        Dimensions: {
            Key: "RECORD_TYPE";
            Values: string[];
        };
    };
}
export interface ForecastRequest {
    TimePeriod: {
        Start: string;
        End: string;
    };
    Granularity: "MONTHLY";
    Metric: string;
}
export interface CostRequests {
    usageByService: CostRequest;
    totals: CostRequest;
    /** Null on the 1st, when the month reported is complete and Cost Explorer forecasts only ahead. */
    forecast: ForecastRequest | null;
}
export interface CostReadings {
    now: Date;
    environment: string;
    services: CostServices;
    /** Every page of the usageByService request's results, from the 1st of the month before. */
    usageByService: CostResultByTime[];
    totals: CostResultByTime[];
    /** The month's forecast, actuals included; null when there is none. */
    forecast: number | null;
}
/** `docs/monitoring/cost-services.json`, checked, since a misspelt key would label nothing. */
export declare function parseCostServices(source: string): CostServices;
/** Cost Explorer's date format. */
export declare function costDate(at: Date): string;
export declare function costWindows(now: Date): CostWindows;
export declare function costRequests(now: Date): CostRequests;
/** Yesterday as a share of its limit, in percent; past 100 the spend rule fires. */
export declare function percentOfSpendLimit(yesterday: number, history: number[]): number;
/** The datapoints one run publishes, each stamped at the end of the window it covers. */
export declare function costDatums(readings: CostReadings): ForwarderDatum[];
//# sourceMappingURL=cost.d.ts.map