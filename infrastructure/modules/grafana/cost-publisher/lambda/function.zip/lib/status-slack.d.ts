import type { StatusComponentId } from "./status-document.js";
import type { StatusEvent } from "./status-events.js";
interface MrkdwnText {
    type: "mrkdwn";
    text: string;
}
type SlackBlock = {
    type: "section";
    text: MrkdwnText;
} | {
    type: "context";
    elements: MrkdwnText[];
};
/** The JSON body of a Slack incoming webhook. `text` is what notifications show. */
export interface SlackMessage {
    text: string;
    blocks: SlackBlock[];
}
/**
 * The English names the page shows, kept beside the ids because the Lambda cannot import the
 * translations. A test in the status app fails when they differ from `component.<id>.name`.
 */
export declare const STATUS_COMPONENT_NAMES: Record<StatusComponentId, string>;
/** The Slack message for one status event. Times are UTC, as on the page. */
export declare function slackMessage(event: StatusEvent): SlackMessage;
export {};
//# sourceMappingURL=status-slack.d.ts.map