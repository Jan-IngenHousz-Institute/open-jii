import { z } from "zod/mini";
/** Bumped when the document's shape changes in a way an older page cannot read. */
export declare const STATUS_DOCUMENT_VERSION = 1;
/**
 * The page polls every minute, so a change reaches it within two minutes only while the file is
 * cached for at most 30 seconds. stale-if-error keeps the last file served through an origin outage.
 */
export declare const STATUS_DOCUMENT_CACHE_CONTROL = "public, max-age=30, stale-if-error=86400";
/** Days of history kept and shown, counted in UTC. */
export declare const STATUS_HISTORY_DAYS = 90;
export declare const DAY_MINUTES = 1440;
export declare const STATUS_COMPONENT_IDS: readonly ["website", "sign-in", "platform", "data-intake", "data-delivery", "macro-processing", "exports"];
export declare const statusComponentIdSchema: z.ZodMiniEnum<{
    platform: "platform";
    website: "website";
    "sign-in": "sign-in";
    "data-intake": "data-intake";
    "data-delivery": "data-delivery";
    "macro-processing": "macro-processing";
    exports: "exports";
}>;
export type StatusComponentId = z.infer<typeof statusComponentIdSchema>;
/** "maintenance" while a planned window that names the component is open, whatever was measured. */
export declare const componentStateSchema: z.ZodMiniEnum<{
    operational: "operational";
    degraded: "degraded";
    outage: "outage";
    maintenance: "maintenance";
}>;
export type ComponentState = z.infer<typeof componentStateSchema>;
/** A day's worst state; "none" marks a day before checks began. */
declare const dayStateSchema: z.ZodMiniEnum<{
    operational: "operational";
    degraded: "degraded";
    outage: "outage";
    maintenance: "maintenance";
    none: "none";
}>;
export type DayState = z.infer<typeof dayStateSchema>;
export declare const dayRecordSchema: z.ZodMiniObject<{
    date: z.iso.ZodMiniISODate;
    state: z.ZodMiniEnum<{
        operational: "operational";
        degraded: "degraded";
        outage: "outage";
        maintenance: "maintenance";
        none: "none";
    }>;
    recordedMinutes: z.ZodMiniInt;
    downMinutes: z.ZodMiniInt;
    degradedMinutes: z.ZodMiniInt;
    maintenanceMinutes: z.ZodMiniInt;
    unknownMinutes: z.ZodMiniInt;
}, z.core.$strip>;
export type DayRecord = z.infer<typeof dayRecordSchema>;
declare const statusComponentSchema: z.ZodMiniObject<{
    id: z.ZodMiniEnum<{
        platform: "platform";
        website: "website";
        "sign-in": "sign-in";
        "data-intake": "data-intake";
        "data-delivery": "data-delivery";
        "macro-processing": "macro-processing";
        exports: "exports";
    }>;
    state: z.ZodMiniEnum<{
        operational: "operational";
        degraded: "degraded";
        outage: "outage";
        maintenance: "maintenance";
    }>;
    delayMinutes: z.ZodMiniOptional<z.ZodMiniInt>;
    uptimePercent: z.ZodMiniNumber<number>;
    degradedMinutes: z.ZodMiniInt;
    days: z.ZodMiniArray<z.ZodMiniObject<{
        date: z.iso.ZodMiniISODate;
        state: z.ZodMiniEnum<{
            operational: "operational";
            degraded: "degraded";
            outage: "outage";
            maintenance: "maintenance";
            none: "none";
        }>;
        recordedMinutes: z.ZodMiniInt;
        downMinutes: z.ZodMiniInt;
        degradedMinutes: z.ZodMiniInt;
        maintenanceMinutes: z.ZodMiniInt;
        unknownMinutes: z.ZodMiniInt;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type StatusComponent = z.infer<typeof statusComponentSchema>;
export declare const incidentStageSchema: z.ZodMiniEnum<{
    investigating: "investigating";
    identified: "identified";
    monitoring: "monitoring";
    resolved: "resolved";
    scheduled: "scheduled";
    "in-progress": "in-progress";
    completed: "completed";
}>;
export declare const nonEmptyText: z.ZodMiniString<string>;
export declare const incidentUpdateSchema: z.ZodMiniObject<{
    id: z.ZodMiniString<string>;
    stage: z.ZodMiniEnum<{
        investigating: "investigating";
        identified: "identified";
        monitoring: "monitoring";
        resolved: "resolved";
        scheduled: "scheduled";
        "in-progress": "in-progress";
        completed: "completed";
    }>;
    postedAt: z.iso.ZodMiniISODateTime;
    text: z.ZodMiniString<string>;
    nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
}, z.core.$strip>;
export declare const incidentSchema: z.ZodMiniObject<{
    id: z.ZodMiniString<string>;
    kind: z.ZodMiniEnum<{
        maintenance: "maintenance";
        incident: "incident";
    }>;
    title: z.ZodMiniString<string>;
    impact: z.ZodMiniEnum<{
        degraded: "degraded";
        outage: "outage";
    }>;
    components: z.ZodMiniArray<z.ZodMiniEnum<{
        platform: "platform";
        website: "website";
        "sign-in": "sign-in";
        "data-intake": "data-intake";
        "data-delivery": "data-delivery";
        "macro-processing": "macro-processing";
        exports: "exports";
    }>>;
    startsAt: z.iso.ZodMiniISODateTime;
    endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    updates: z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        stage: z.ZodMiniEnum<{
            investigating: "investigating";
            identified: "identified";
            monitoring: "monitoring";
            resolved: "resolved";
            scheduled: "scheduled";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        postedAt: z.iso.ZodMiniISODateTime;
        text: z.ZodMiniString<string>;
        nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type Incident = z.infer<typeof incidentSchema>;
/**
 * When it is over: its resolution, or for planned work the earlier of that and its scheduled end.
 * It may still be ahead of now.
 */
export declare function endedAt(incident: Pick<Incident, "kind" | "endsAt" | "resolvedAt">): string | undefined;
export type IncidentUpdate = z.infer<typeof incidentUpdateSchema>;
export declare const noticeSchema: z.ZodMiniObject<{
    id: z.ZodMiniString<string>;
    title: z.ZodMiniString<string>;
    body: z.ZodMiniString<string>;
    severity: z.ZodMiniEnum<{
        critical: "critical";
        warning: "warning";
        info: "info";
    }>;
}, z.core.$strip>;
export type Notice = z.infer<typeof noticeSchema>;
export declare const statusDocumentSchema: z.ZodMiniObject<{
    version: z.ZodMiniLiteral<1>;
    generatedAt: z.iso.ZodMiniISODateTime;
    components: z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>;
        state: z.ZodMiniEnum<{
            operational: "operational";
            degraded: "degraded";
            outage: "outage";
            maintenance: "maintenance";
        }>;
        delayMinutes: z.ZodMiniOptional<z.ZodMiniInt>;
        uptimePercent: z.ZodMiniNumber<number>;
        degradedMinutes: z.ZodMiniInt;
        days: z.ZodMiniArray<z.ZodMiniObject<{
            date: z.iso.ZodMiniISODate;
            state: z.ZodMiniEnum<{
                operational: "operational";
                degraded: "degraded";
                outage: "outage";
                maintenance: "maintenance";
                none: "none";
            }>;
            recordedMinutes: z.ZodMiniInt;
            downMinutes: z.ZodMiniInt;
            degradedMinutes: z.ZodMiniInt;
            maintenanceMinutes: z.ZodMiniInt;
            unknownMinutes: z.ZodMiniInt;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    incidents: z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        title: z.ZodMiniString<string>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        updates: z.ZodMiniArray<z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            stage: z.ZodMiniEnum<{
                investigating: "investigating";
                identified: "identified";
                monitoring: "monitoring";
                resolved: "resolved";
                scheduled: "scheduled";
                "in-progress": "in-progress";
                completed: "completed";
            }>;
            postedAt: z.iso.ZodMiniISODateTime;
            text: z.ZodMiniString<string>;
            nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    notices: z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        body: z.ZodMiniString<string>;
        severity: z.ZodMiniEnum<{
            critical: "critical";
            warning: "warning";
            info: "info";
        }>;
    }, z.core.$strip>>;
    messagesPerMinute: z.ZodMiniOptional<z.ZodMiniNumber<number>>;
}, z.core.$strip>;
export type StatusDocument = z.infer<typeof statusDocumentSchema>;
/**
 * What a page parses. A component added after the page was built is dropped rather than failing
 * the whole document, and so is an incident left naming none, so a publisher deployed before the
 * page cannot take the page down.
 */
export declare const readableStatusDocumentSchema: z.ZodMiniObject<{
    version: z.ZodMiniLiteral<1>;
    generatedAt: z.iso.ZodMiniISODateTime;
    notices: z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        body: z.ZodMiniString<string>;
        severity: z.ZodMiniEnum<{
            critical: "critical";
            warning: "warning";
            info: "info";
        }>;
    }, z.core.$strip>>;
    messagesPerMinute: z.ZodMiniOptional<z.ZodMiniNumber<number>>;
    components: z.ZodMiniPipe<z.ZodMiniPipe<z.ZodMiniArray<z.ZodMiniUnknown>, z.ZodMiniTransform<unknown[], unknown[]>>, z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>;
        state: z.ZodMiniEnum<{
            operational: "operational";
            degraded: "degraded";
            outage: "outage";
            maintenance: "maintenance";
        }>;
        delayMinutes: z.ZodMiniOptional<z.ZodMiniInt>;
        uptimePercent: z.ZodMiniNumber<number>;
        degradedMinutes: z.ZodMiniInt;
        days: z.ZodMiniArray<z.ZodMiniObject<{
            date: z.iso.ZodMiniISODate;
            state: z.ZodMiniEnum<{
                operational: "operational";
                degraded: "degraded";
                outage: "outage";
                maintenance: "maintenance";
                none: "none";
            }>;
            recordedMinutes: z.ZodMiniInt;
            downMinutes: z.ZodMiniInt;
            degradedMinutes: z.ZodMiniInt;
            maintenanceMinutes: z.ZodMiniInt;
            unknownMinutes: z.ZodMiniInt;
        }, z.core.$strip>>;
    }, z.core.$strip>>>;
    incidents: z.ZodMiniPipe<z.ZodMiniPipe<z.ZodMiniArray<z.ZodMiniUnknown>, z.ZodMiniTransform<unknown[], unknown[]>>, z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        title: z.ZodMiniString<string>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        updates: z.ZodMiniArray<z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            stage: z.ZodMiniEnum<{
                investigating: "investigating";
                identified: "identified";
                monitoring: "monitoring";
                resolved: "resolved";
                scheduled: "scheduled";
                "in-progress": "in-progress";
                completed: "completed";
            }>;
            postedAt: z.iso.ZodMiniISODateTime;
            text: z.ZodMiniString<string>;
            nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        }, z.core.$strip>>;
    }, z.core.$strip>>>;
}, z.core.$strip>;
export {};
//# sourceMappingURL=status-document.d.ts.map