/**
 * The website check's address for one minute. The web distribution keeps a page for as long as its
 * origin allows stale copies, so a fresh query string each minute makes it ask the web server.
 */
export declare function websiteProbeUrl(pageUrl: string, now: Date): string;
/** A page that renders the product's name is up; an empty 200 from a broken deploy is not. */
export declare function isWebsiteHealthy(body: string): boolean;
/** The API's anonymous health endpoint answers `{"status":"ok"}` while it serves. */
export declare function isApiHealthy(body: string): boolean;
//# sourceMappingURL=status-probes.d.ts.map