import type { RegionQueries, StatusReadings } from "./status-components.js";
/** The parts of a GetMetricData result a reading needs, so the package needs no SDK. */
interface MetricDataResult {
    Id?: string;
    StatusCode?: string;
    Timestamps?: Date[];
    Values?: number[];
}
interface MetricDataPage {
    NextToken?: string;
    MetricDataResults?: MetricDataResult[];
}
/**
 * Results CloudWatch could not answer. They would read as no datapoints, which the judge takes for a
 * quiet signal or a silent producer, so the run has to stop instead. PartialData only means more
 * pages follow until the last one.
 */
export declare function unreadableResults(page: MetricDataPage): MetricDataResult[];
type ReadingSpec = RegionQueries["readings"][number];
/**
 * Turns one region's GetMetricData results into readings, each over its own lookback. A signal
 * with no datapoint in its window has no reading, which the judge reads per signal: an absent
 * count is none, an absent heartbeat is a silent producer.
 */
export declare function collapseReadings(specs: ReadingSpec[], results: MetricDataResult[], now: Date): StatusReadings;
export {};
//# sourceMappingURL=status-readings.d.ts.map