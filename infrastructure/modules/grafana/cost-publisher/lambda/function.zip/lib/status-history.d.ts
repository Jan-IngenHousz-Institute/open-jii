import type { ComponentState, DayRecord, DayState } from "./status-document.js";
/** Short blips stay visible in the day's details but do not colour the bar. */
export declare const DAY_DEGRADED_MINUTES = 5;
type DayCounts = Pick<DayRecord, "recordedMinutes" | "downMinutes" | "degradedMinutes" | "maintenanceMinutes" | "unknownMinutes">;
/** Minutes since the epoch, the unit every record is kept in so a minute can be counted only once. */
export declare function minuteOf(at: Date): number;
/**
 * The worst state a day measured. Degraded minutes colour it only from `DAY_DEGRADED_MINUTES`, and
 * unknown minutes never do, since a gap in our checks says nothing about the service. A day with
 * none measured has no colour at all.
 */
export declare function dayState(counts: DayCounts): DayState;
/** Counts one minute on its UTC day. The caller guarantees it has not been recorded before. */
export declare function recordMinute(days: DayRecord[], minute: number, outcome: ComponentState, incidentIds: string[]): DayRecord[];
/**
 * Counts the minutes from `fromMinute` to `toMinute`, both included, as ones our checks could not
 * run, each on its own UTC day. A gap longer than the history is cut to it, since the rest would be
 * trimmed at once.
 */
export declare function recordUnknown(days: DayRecord[], fromMinute: number, toMinute: number): DayRecord[];
/**
 * Time the component was up, as a percent. Unknown minutes count against it, and maintenance is
 * left out of both sides, so planned work neither costs a component nor flatters it.
 */
export declare function uptimePercent(days: DayRecord[]): number;
export declare function totalDegradedMinutes(days: DayRecord[]): number;
export {};
//# sourceMappingURL=status-history.d.ts.map