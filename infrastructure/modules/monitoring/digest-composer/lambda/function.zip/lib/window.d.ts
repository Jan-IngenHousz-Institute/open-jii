import type { CatalogMetric } from "./types.js";
export interface TimeWindow {
    start: Date;
    end: Date;
}
export interface RegionEntry {
    metric: CatalogMetric;
    index: number;
}
/** One series as GetMetricData returns it; a SEARCH expression returns several per Id. */
export interface SeriesResult {
    Id?: string;
    Values?: number[];
}
export declare function dailyWindows(now: number): {
    current: TimeWindow;
    history: TimeWindow[];
};
export declare function weeklyWindows(now: number): {
    current: TimeWindow;
    prior: TimeWindow;
};
/**
 * Groups metrics for one GetMetricData call each. The index is the metric's position in
 * the original list, which is what carries its identity through the query and back.
 */
export declare function groupByRegion(metrics: CatalogMetric[]): Map<string, RegionEntry[]>;
/** Collects a response's series back onto the metric indices that asked for them. */
export declare function readSeries(results: SeriesResult[] | undefined, into?: Map<number, number[]>): Map<number, number[]>;
/**
 * Turns collected series into one value per metric.
 *
 * Absent and unasked are different facts, which is the whole reason this takes
 * `unqueried`: an absent Sum normalizes to zero, so a metric from a region we failed to
 * read would otherwise report an error counter of zero, meaning healthy.
 */
export declare function assembleWindow(metrics: CatalogMetric[], values: Map<number, number[]>, unqueried: ReadonlySet<number>): (number | null)[];
//# sourceMappingURL=window.d.ts.map