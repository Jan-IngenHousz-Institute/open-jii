import type { SelfChecks } from "./render.js";
import type { EvaluatedReading, MetricReading } from "./types.js";
/**
 * A self-contained HTML report, one per digest.
 *
 * Slack carries the verdict and a link; this carries the reasoning. It reads top to
 * bottom as a briefing rather than a spreadsheet: what needs attention, written out,
 * with its chart; then what moved; then the full table for anyone who wants it. One
 * file with styles and charts inlined, so it survives being saved or mailed and needs
 * no network of its own.
 */
export interface ReportInput {
    title: string;
    environment: string;
    generatedAt: Date;
    /** What the readings are compared against, in words a reader would use. */
    window: string;
    /** The one sentence someone reads if they read nothing else. */
    verdict: string;
    /** Written out in full, each with its chart. Empty on a quiet day. */
    attention: EvaluatedReading[];
    /** Everything read this run, for the table at the bottom. */
    everything: (EvaluatedReading | MetricReading)[];
    checks: SelfChecks;
    /** Base64 PNGs from CloudWatch, keyed by metric id. */
    charts: Record<string, string>;
    catalogUrl?: string;
    runbookBaseUrl?: string;
}
export declare function renderReport(input: ReportInput): string;
//# sourceMappingURL=report.d.ts.map