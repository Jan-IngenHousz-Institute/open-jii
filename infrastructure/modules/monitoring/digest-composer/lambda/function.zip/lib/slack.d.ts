/**
 * Slack Block Kit.
 *
 * A webhook accepts either a `text` string or a `blocks` array. Every message here
 * carries both, so the notification preview and any client that cannot render blocks
 * still say something useful, and the composer has something to log when no webhook is
 * configured.
 */
export interface SlackBlock {
    type: string;
    [key: string]: unknown;
}
export interface SlackMessage {
    /** Notification preview, and what the composer logs when no webhook is set. */
    text: string;
    blocks: SlackBlock[];
}
export interface LinkButton {
    label: string;
    url: string;
}
export declare function header(text: string): SlackBlock;
export declare function context(text: string): SlackBlock;
export declare function divider(): SlackBlock;
export declare function section(text: string): SlackBlock;
export declare function image(url: string, altText: string): SlackBlock;
export declare function actions(buttons: LinkButton[]): SlackBlock;
export declare function table(rows: string[][]): string;
/**
 * The table as one section per chunk that fits Slack's limit, so a long list splits rather
 * than being rejected. Columns are measured across all rows first, so the chunks line up.
 */
export declare function tableSections(rows: string[][]): SlackBlock[];
//# sourceMappingURL=slack.d.ts.map