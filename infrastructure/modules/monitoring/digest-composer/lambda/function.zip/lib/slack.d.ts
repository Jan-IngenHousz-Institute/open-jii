/**
 * Slack Block Kit.
 *
 * A webhook accepts either a `text` string or a `blocks` array. Every message here
 * carries both, so the notification preview and any client that cannot render blocks
 * still say something useful, and the composer has something to log when no webhook is
 * configured.
 */
export interface SlackBlock {
    type: string;
    [key: string]: unknown;
}
export interface SlackMessage {
    /** Notification preview, and what the composer logs when no webhook is set. */
    text: string;
    blocks: SlackBlock[];
}
export interface LinkButton {
    label: string;
    url: string;
}
export declare function header(text: string): SlackBlock;
export declare function context(text: string): SlackBlock;
export declare function divider(): SlackBlock;
export declare function section(text: string): SlackBlock;
export declare function image(url: string, altText: string): SlackBlock;
export declare function actions(buttons: LinkButton[]): SlackBlock;
/**
 * Columns only line up inside a code block, so a table is preformatted text.
 *
 * Rows arrive as cells already rendered; this pads them, which is the only thing that
 * makes a list of figures scannable rather than a paragraph of numbers.
 */
export declare function table(rows: string[][]): string;
//# sourceMappingURL=slack.d.ts.map