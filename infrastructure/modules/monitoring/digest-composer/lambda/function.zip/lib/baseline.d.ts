import type { Evaluation, MetricReading } from "./types.js";
/** Absent datapoints for a counter mean zero events, not a broken signal. */
export declare function normalizeAbsent(value: number | null, stat: string | undefined): number | null;
export declare function aggregate(values: number[], stat: string | undefined): number | null;
export declare function averageBaseline(history: (number | null)[]): number | null;
export declare function deviationPercent(value: number, baseline: number | null): number | null;
export declare function evaluate({ metric, value, baseline, historyCount }: MetricReading): Evaluation;
//# sourceMappingURL=baseline.d.ts.map