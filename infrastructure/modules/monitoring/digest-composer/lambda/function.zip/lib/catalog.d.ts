import type { CatalogMetric, CatalogPass } from "./types.js";
/** Placeholders let one catalog serve every environment; values come from the Lambda env. */
export declare function resolvePlaceholders(value: string, env: Record<string, string | undefined>): string;
export declare function parseCatalog(source: string): CatalogMetric[];
export declare function parsePasses(source: string): CatalogPass[];
/** Metrics the composer can actually query; everything else is documentation. */
export declare function activeSignals(metrics: CatalogMetric[]): CatalogMetric[];
export declare function buildQuery(metric: CatalogMetric, index: number, env: Record<string, string | undefined>): {
    Id: string;
    Expression: string;
    Period: number;
    MetricStat?: undefined;
} | {
    Id: string;
    MetricStat: {
        Metric: {
            Namespace: string | undefined;
            MetricName: string | undefined;
            Dimensions: {
                Name: string;
                Value: string;
            }[];
        };
        Period: number;
        Stat: string | undefined;
    };
    Expression?: undefined;
    Period?: undefined;
};
/**
 * Drops metrics whose placeholders cannot resolve, so one misconfigured entry
 * costs its own line rather than the whole digest.
 *
 * The probe is placeholder resolution, deliberately not buildQuery: buildQuery only
 * knows the CloudWatch shapes, so using it here would mark every entry of a newer
 * signal kind as misconfigured rather than simply unfetchable by this composer.
 */
export declare function partitionByConfig(metrics: CatalogMetric[], env: Record<string, string | undefined>): {
    usable: CatalogMetric[];
    configErrors: string[];
};
//# sourceMappingURL=catalog.d.ts.map