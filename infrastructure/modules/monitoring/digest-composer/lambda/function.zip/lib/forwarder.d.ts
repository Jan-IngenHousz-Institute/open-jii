import type { ForwarderDatum, SkippedLine } from "./types.js";
/** Namespaces the forwarder role is allowed to publish into. */
export declare const ALLOWED_NAMESPACES: Set<string>;
export interface ParseResult {
    observations: ForwarderDatum[];
    skipped: SkippedLine[];
}
/**
 * Parse the NDJSON heartbeat file. Lines carrying a "metric" key become CloudWatch
 * datapoints; "detail" roster lines stay in S3, which is what keeps per-experiment
 * cardinality out of CloudWatch. Their reader today is the openjii-triage skill and
 * whoever is holding an incident; the digest does not read them yet.
 */
export declare function parseObservations(body: string): ParseResult;
/** PutMetricData takes one namespace per call and caps datapoints per request. */
export declare function batchByNamespace(observations: ForwarderDatum[], batchSize: number): {
    namespace: string;
    data: ForwarderDatum["datum"][];
}[];
//# sourceMappingURL=forwarder.d.ts.map