/**
 * How a number reaches a human.
 *
 * CloudWatch hands back a bare float, so without the catalog's unit an iterator age of
 * 8797000 renders as "8.8M" and means nothing. Every signal that is not a plain count
 * declares its unit and gets read back in the terms someone would actually say.
 */
/** Units a signal may declare. Anything else, including nothing, reads as a count. */
export type MetricUnit = "milliseconds" | "seconds" | "minutes" | "bytes" | "percent";
export declare function formatValue(value: number, unit?: string): string;
//# sourceMappingURL=format.d.ts.map