import type { SlackMessage } from "./slack.js";
import type { EvaluatedReading, MetricReading } from "./types.js";
export interface RenderOptions {
    environment: string;
    runbookBaseUrl?: string;
    /** Where the catalog entry lives, so a reader can change what a signal means. */
    catalogUrl?: string;
    /**
     * The full report for this run. Slack carries the verdict and the table; everything
     * a reader might want after that lives one click away rather than in the message.
     */
    reportUrl?: string;
}
export declare function deltaGlyph(value: number, baseline: number | null, window: string): string;
/** Things that went wrong with the digest itself, as opposed to with the platform. */
export interface SelfChecks {
    configErrors: string[];
    failedRegions: string[];
}
export declare function renderObservability(readings: EvaluatedReading[], checks: SelfChecks, options: RenderOptions): SlackMessage;
export declare function renderLevels(readings: MetricReading[], checks: SelfChecks, title: string, window: string, options: RenderOptions): SlackMessage;
//# sourceMappingURL=render.d.ts.map