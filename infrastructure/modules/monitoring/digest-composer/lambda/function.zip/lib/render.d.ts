import type { SlackMessage } from "./slack.js";
import type { EvaluatedReading, MetricReading } from "./types.js";
/**
 * A parent message and one reply per anomaly.
 *
 * The parent is the whole morning at a glance. Each reply carries one anomaly's
 * identifier, its runbook and its triage command, so the channel stays one table however
 * bad the day is and nobody scrolls past the first problem to reach the second.
 *
 * With no bot token there is nothing to thread under, and `flatten` puts the replies
 * inline instead.
 */
export interface Digest {
    parent: SlackMessage;
    replies: SlackMessage[];
}
export interface RenderOptions {
    environment: string;
    runbookBaseUrl?: string;
    /**
     * The full report for this run. Slack carries the verdict and the table; everything
     * a reader might want after that lives one click away rather than in the message.
     */
    reportUrl?: string;
}
export declare function deltaGlyph(value: number, baseline: number | null, window: string): string;
/** Things that went wrong with the digest itself, as opposed to with the platform. */
export interface SelfChecks {
    configErrors: string[];
    failedRegions: string[];
}
export declare function renderObservability(readings: EvaluatedReading[], checks: SelfChecks, options: RenderOptions): Digest;
export declare function renderLevels(readings: MetricReading[], checks: SelfChecks, title: string, window: string, options: RenderOptions): Digest;
/**
 * The digest as one message, for a transport that cannot thread.
 *
 * A webhook returns no message timestamp, so replies have nothing to hang under. Dropping
 * them would lose each anomaly's runbook and triage command, which are the two things that
 * turn a reading into an action. They go inline under the summary instead, most severe
 * first, and whatever does not fit the block limit is left to the report.
 */
export declare function flatten({ parent, replies }: Digest): SlackMessage;
//# sourceMappingURL=render.d.ts.map