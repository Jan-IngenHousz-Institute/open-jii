import type { Evaluation, MetricReading } from "./types.js";
export interface EvaluatedReading extends MetricReading {
    evaluation: Evaluation;
}
export interface RenderOptions {
    environment: string;
    runbookBaseUrl?: string;
}
export declare function formatValue(value: number): string;
export declare function deltaGlyph(value: number, baseline: number | null, window: string): string;
export declare function renderObservability(readings: EvaluatedReading[], configErrors: string[], { environment, runbookBaseUrl }: RenderOptions): string;
export declare function renderLevels(readings: MetricReading[], title: string, window: string, { environment }: RenderOptions): string;
//# sourceMappingURL=render.d.ts.map