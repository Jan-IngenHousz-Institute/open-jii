import type { SlackMessage } from "./slack.js";
import type { EvaluatedReading, MetricReading } from "./types.js";
/**
 * A parent message and one reply per anomaly.
 *
 * The parent is the whole morning at a glance. Each reply carries one anomaly's
 * identifier, its runbook and its triage command, so the channel stays one table however
 * bad the day is and nobody scrolls past the first problem to reach the second.
 *
 * With no bot token the composer posts the parent alone, so the replies are additive
 * rather than a prerequisite.
 */
export interface Digest {
    parent: SlackMessage;
    replies: SlackMessage[];
}
export interface RenderOptions {
    environment: string;
    runbookBaseUrl?: string;
    /**
     * The full report for this run. Slack carries the verdict and the table; everything
     * a reader might want after that lives one click away rather than in the message.
     */
    reportUrl?: string;
}
export declare function deltaGlyph(value: number, baseline: number | null, window: string): string;
/** Things that went wrong with the digest itself, as opposed to with the platform. */
export interface SelfChecks {
    configErrors: string[];
    failedRegions: string[];
}
export declare function renderObservability(readings: EvaluatedReading[], checks: SelfChecks, options: RenderOptions): Digest;
export declare function renderLevels(readings: MetricReading[], checks: SelfChecks, title: string, window: string, options: RenderOptions): Digest;
//# sourceMappingURL=render.d.ts.map