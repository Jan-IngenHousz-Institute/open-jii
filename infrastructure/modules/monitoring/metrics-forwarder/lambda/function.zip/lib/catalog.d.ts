import type { CatalogMetric, CatalogPass } from "./types.js";
export declare function parseCatalog(source: string): CatalogMetric[];
export declare function parsePasses(source: string): CatalogPass[];
//# sourceMappingURL=catalog.d.ts.map