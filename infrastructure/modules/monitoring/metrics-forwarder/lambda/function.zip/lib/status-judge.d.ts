import { z } from "zod/mini";
import type { StatusReadings } from "./status-components.js";
import type { ComponentState, Incident, Notice, StatusComponentId, StatusDocument } from "./status-document.js";
/** A page that takes longer than this to answer feels broken to a visitor, even though it loads. */
export declare const WEBSITE_SLOW_PROBE_MS = 3000;
/** The API answers a cheap health request, so two seconds means it is struggling. */
export declare const PLATFORM_SLOW_PROBE_MS = 2000;
/**
 * One bad minute is often a cold start, a dropped request or a pipeline restarting, so degraded
 * needs two in a row. Grafana's alerts wait in the same way before they fire.
 */
export declare const MINUTES_FOR_DEGRADED = 2;
/** One failed minute is often the network between us and the service, three in a row is the service. */
export declare const MINUTES_FOR_OUTAGE = 3;
/** Past half the requests failing, CloudFront is not serving the site. */
export declare const WEBSITE_OUTAGE_ERROR_PERCENT = 50;
/** Fewer requests than this in the window make an error rate noise, so it cannot declare an outage. */
export declare const WEBSITE_MIN_REQUESTS = 20;
/** Past half the requests answered with a 5xx, the API is failing more than it serves. */
export declare const PLATFORM_OUTAGE_ERROR_SHARE = 0.5;
/** A handful of errors in a quiet window is a blip, so an outage needs at least this many. */
export declare const PLATFORM_MIN_ERRORS = 10;
/** A few failed forwards can be a retry that lands, so only past this many is data being lost. */
export declare const INGEST_OUTAGE_FAILURES = 5;
/** Researchers notice data that arrives a quarter of an hour late, so that is degraded. */
export declare const DELIVERY_DEGRADED_LATENCY_MINUTES = 15;
/** An hour behind, new measurements are effectively not arriving. */
export declare const DELIVERY_OUTAGE_LATENCY_MINUTES = 60;
/** The consumer ten minutes behind the stream is falling behind rather than catching up. */
export declare const ITERATOR_AGE_DEGRADED_MINUTES = 10;
/** Bronze idle this long while devices publish is a stopped pipeline, as Ingest Stalled reads it. */
export declare const DELIVERY_STALL_IDLE_MINUTES = 60;
/** Macro results more than five minutes after their measurement are slower than a researcher expects. */
export declare const MACRO_DEGRADED_LATENCY_MINUTES = 5;
/** Half an hour late, macro results are not usable while the researcher is still at the device. */
export declare const MACRO_OUTAGE_LATENCY_MINUTES = 30;
export declare const PUBLISHER_STATE_VERSION = 2;
/** What the publisher carries between runs. It holds history the document shows and nothing more. */
export declare const publisherStateSchema: z.ZodMiniObject<{
    version: z.ZodMiniLiteral<2>;
    lastJudgedAt: z.iso.ZodMiniISODateTime;
    components: z.ZodMiniRecord<z.ZodMiniEnum<{
        platform: "platform";
        website: "website";
        "sign-in": "sign-in";
        "data-intake": "data-intake";
        "data-delivery": "data-delivery";
        "macro-processing": "macro-processing";
        exports: "exports";
    }> & z.core.$partial, z.ZodMiniObject<{
        degradedStreak: z.ZodMiniInt;
        outageStreak: z.ZodMiniInt;
        days: z.ZodMiniArray<z.ZodMiniObject<{
            date: z.iso.ZodMiniISODate;
            state: z.ZodMiniEnum<{
                operational: "operational";
                degraded: "degraded";
                outage: "outage";
                maintenance: "maintenance";
                none: "none";
            }>;
            recordedMinutes: z.ZodMiniInt;
            downMinutes: z.ZodMiniInt;
            degradedMinutes: z.ZodMiniInt;
            maintenanceMinutes: z.ZodMiniInt;
            unknownMinutes: z.ZodMiniInt;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type PublisherState = z.infer<typeof publisherStateSchema>;
export interface StatusProbeResult {
    ok: boolean;
    durationMs: number;
}
export interface StatusProbes {
    website: StatusProbeResult;
    platform: StatusProbeResult;
}
export interface ComponentEvidence {
    /** This minute's probes; a component without its own ignores them. */
    probes: StatusProbes;
    readings: StatusReadings;
}
/** What the checks can say; maintenance comes only from a planned window. */
type MeasuredState = Exclude<ComponentState, "maintenance">;
interface ComponentVerdict {
    state: MeasuredState;
    /** How far behind new measurements are, when that is what the state says. */
    delayMinutes?: number;
}
export declare function worstState(states: MeasuredState[]): MeasuredState;
/** The worst state any rule of the component reaches in this one minute, before it has held long enough to show. */
export declare function judgeComponent(id: StatusComponentId, evidence: ComponentEvidence): ComponentVerdict;
/**
 * Open from its start until it is resolved. Planned work also ends at its scheduled end, so a
 * window nobody closed cannot hide a real outage behind it.
 */
export declare function isOpen(incident: Incident, atMs: number): boolean;
interface JudgeInput {
    now: Date;
    probes: StatusProbes;
    readings: StatusReadings;
    /** Undefined on the first run. */
    previous: PublisherState | undefined;
    incidents: Incident[];
    notices: Notice[];
}
export interface JudgeResult {
    document: StatusDocument;
    state: PublisherState;
}
/**
 * Judges one run: the live components' states, their history with this minute recorded, and the
 * document to publish. A run in a minute already judged changes no history, so a retried invocation
 * cannot count it twice.
 */
export declare function judgeStatus(input: JudgeInput): JudgeResult;
export {};
//# sourceMappingURL=status-judge.d.ts.map