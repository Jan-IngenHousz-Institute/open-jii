/** A page that renders the product's name is up; an empty 200 from a broken deploy is not. */
export declare function isWebsiteHealthy(body: string): boolean;
/** The API's anonymous health endpoint answers `{"status":"ok"}` while it serves. */
export declare function isApiHealthy(body: string): boolean;
//# sourceMappingURL=status-probes.d.ts.map