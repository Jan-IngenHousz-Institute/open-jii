import type { StatusComponentId } from "./status-document.js";
export type StatusRegion = "eu-central-1" | "us-east-1";
/** The identifiers that differ per environment; everything else a query names is fixed. */
export interface StatusConfig {
    environment: string;
    albArnSuffix: string;
    webDistributionId: string;
    kinesisStreamName: string;
}
/** The parts of the AWS SDK's `MetricDataQuery` the status queries use, so the package needs no SDK. */
export interface MetricDataQuery {
    Id: string;
    MetricStat?: {
        Metric: {
            Namespace: string;
            MetricName: string;
            Dimensions: {
                Name: string;
                Value: string;
            }[];
        };
        Period: number;
        Stat: string;
    };
    Expression?: string;
    ReturnData?: boolean;
}
export declare const STATUS_SIGNAL_IDS: readonly ["websiteRequests", "websiteFailedRequests", "databaseUp", "databricksUp", "albElb5xx", "albTarget5xx", "albRequests", "emailUp", "ingestForwardingFailures", "ingestRefusedPublishes", "ingestThrottled", "iotUp", "deliveryLatencyP95", "ingestIdle", "devicePublishesBeforeIdle", "collectorHeartbeat", "ingestIteratorAge", "macroPlatformFailures", "macroLatencyP95", "macroBacklog", "exportsFailed"];
/** Also the `Id` of the signal's query, which CloudWatch requires to start with a lowercase letter. */
type StatusSignalId = (typeof STATUS_SIGNAL_IDS)[number];
/** Absent means CloudWatch had no datapoint in the signal's lookback. */
export type StatusReadings = Partial<Record<StatusSignalId, number>>;
/**
 * How a signal's datapoints inside its lookback become one reading. A count is summed. A
 * dependency check is the highest, so it reads down only when every check in its window failed. A
 * level is its newest point, so a recovered value stops counting as soon as the next one lands and
 * a one-minute spike lasts one minute.
 */
type SignalReduction = "sum" | "max" | "latest";
/** Every count rule reads this long a window, so one bad minute neither flaps the page nor lingers. */
export declare const RULE_WINDOW_MINUTES = 15;
/** The macro failures rule counts the last hour, since the heartbeat export reports them per half hour. */
export declare const MACRO_FAILURE_WINDOW_MINUTES = 60;
/**
 * The backend checks its dependencies every five minutes with a ten-second timeout, so ten minutes
 * holds two or three checks, and one slow answer between good ones does not show the platform down.
 */
export declare const DEPENDENCY_WINDOW_MINUTES = 10;
/** Iterator age lands every minute the pipeline reads, so a few minutes cover one CloudWatch has not filled yet. */
export declare const LAG_WINDOW_MINUTES = 5;
/**
 * The heartbeat export publishes every half hour. Latencies are stamped at the start of the bucket
 * they measure, so the newest is 30 to 60 minutes old, and 75 minutes tolerates delivery lag but
 * not a missed run, which reads as no latency. The collector heartbeat, stamped at the run, is what
 * shows a dead export.
 */
export declare const PIPELINE_WINDOW_MINUTES = 75;
/**
 * Device publishes from an hour to 45 minutes ago stand beside bronze's idle reading, as Ingest
 * Stalled (catalogue 89) reads them: the reading can be 35 minutes old, and a publish at least
 * five minutes before it had time to reach bronze, so a burst after a quiet spell is no stall.
 */
export declare const STALL_PUBLISHES_START_MINUTES = 60;
export declare const STALL_PUBLISHES_END_MINUTES = 45;
export interface StatusSignal {
    id: StatusSignalId;
    region: StatusRegion;
    periodSeconds: number;
    lookbackMinutes: number;
    /** Where the window ends, when it is not now: a reading of an earlier quarter of an hour, say. */
    endMinutesAgo?: number;
    reduce: SignalReduction;
    /** The query whose result is the reading. */
    query: MetricDataQuery;
    /** Queries the expression reads, fetched with ReturnData off. */
    inputs: MetricDataQuery[];
}
interface StatusComponentDefinition {
    id: StatusComponentId;
    /** Components not yet live are omitted from the document and cost no CloudWatch reads. */
    live: boolean;
    signals: StatusSignalId[];
}
export declare const STATUS_COMPONENTS: StatusComponentDefinition[];
/** Every signal, live or not, with the queries it takes to read it in this environment. */
export declare function statusSignals(config: StatusConfig): StatusSignal[];
export interface RegionQueries {
    region: StatusRegion;
    /** The `MetricDataQueries` of one GetMetricData call, helper queries included. */
    queries: MetricDataQuery[];
    /** The longest lookback of the signals in this region, which sets the call's start time. */
    lookbackMinutes: number;
    /** How to turn each returned query into a reading, over its own lookback. */
    readings: Pick<StatusSignal, "id" | "periodSeconds" | "lookbackMinutes" | "endMinutesAgo" | "reduce">[];
}
/**
 * The reads a run needs, one GetMetricData call per region, for the live components only. A signal
 * two components share, such as the Databricks check, is read once.
 */
export declare function statusQueries(config: StatusConfig): RegionQueries[];
export {};
//# sourceMappingURL=status-components.d.ts.map