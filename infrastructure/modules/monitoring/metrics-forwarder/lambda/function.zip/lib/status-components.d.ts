import type { StatusComponentId } from "./status-document.js";
export type StatusRegion = "eu-central-1" | "us-east-1";
/** The identifiers that differ per environment; everything else a query names is fixed. */
export interface StatusConfig {
    environment: string;
    albArnSuffix: string;
    webDistributionId: string;
    kinesisStreamName: string;
}
/** The parts of the AWS SDK's `MetricDataQuery` the status queries use, so the package needs no SDK. */
export interface MetricDataQuery {
    Id: string;
    MetricStat?: {
        Metric: {
            Namespace: string;
            MetricName: string;
            Dimensions: {
                Name: string;
                Value: string;
            }[];
        };
        Period: number;
        Stat: string;
    };
    Expression?: string;
    ReturnData?: boolean;
}
export declare const STATUS_SIGNAL_IDS: readonly ["websiteRequests", "websiteFailedRequests", "databaseUp", "databricksUp", "albElb5xx", "albTarget5xx", "albRequests", "emailUp", "ingestForwardingFailures", "ingestRefusedPublishes", "ingestThrottled", "iotUp", "ingestPublished", "experimentLatencyP95", "collectorHeartbeat", "ingestIteratorAge", "macroPlatformFailures", "macroLatencyP95", "macroBacklog", "exportsFailed"];
/** Also the `Id` of the signal's query, which CloudWatch requires to start with a lowercase letter. */
type StatusSignalId = (typeof STATUS_SIGNAL_IDS)[number];
/** Absent means CloudWatch had no datapoint in the signal's lookback. */
export type StatusReadings = Partial<Record<StatusSignalId, number>>;
/**
 * How a signal's datapoints inside its lookback become one reading. A count is summed, a
 * level the rules compare with a limit is the highest, and a gauge published every few minutes
 * is its newest point, so a recovered value stops counting as soon as the next one lands.
 */
type SignalReduction = "sum" | "max" | "latest";
/** Every count rule reads this long a window, so one bad minute neither flaps the page nor lingers. */
export declare const RULE_WINDOW_MINUTES = 15;
/** The macro failures rule counts the last hour, since the heartbeat export reports them per half hour. */
export declare const MACRO_FAILURE_WINDOW_MINUTES = 60;
/** The backend checks its dependencies every five minutes, so ten spans one missed check. */
export declare const DEPENDENCY_WINDOW_MINUTES = 10;
/** Iterator age moves slowly, so a few minutes is enough to read its level. */
export declare const LAG_WINDOW_MINUTES = 5;
/** The messages per minute figure averages over this many minutes. */
export declare const INGEST_THROUGHPUT_WINDOW_MINUTES = 5;
/**
 * The heartbeat export publishes every half hour, so 75 minutes spans two missed runs plus delivery
 * lag; a collector silent for that long is stopped, not late.
 */
export declare const PIPELINE_WINDOW_MINUTES = 75;
export interface StatusSignal {
    id: StatusSignalId;
    region: StatusRegion;
    periodSeconds: number;
    lookbackMinutes: number;
    reduce: SignalReduction;
    /** The query whose result is the reading. */
    query: MetricDataQuery;
    /** Queries the expression reads, fetched with ReturnData off. */
    inputs: MetricDataQuery[];
}
interface StatusComponentDefinition {
    id: StatusComponentId;
    /** Components not yet live are omitted from the document and cost no CloudWatch reads. */
    live: boolean;
    signals: StatusSignalId[];
}
export declare const STATUS_COMPONENTS: StatusComponentDefinition[];
/** Every signal, live or not, with the queries it takes to read it in this environment. */
export declare function statusSignals(config: StatusConfig): StatusSignal[];
export interface RegionQueries {
    region: StatusRegion;
    /** The `MetricDataQueries` of one GetMetricData call, helper queries included. */
    queries: MetricDataQuery[];
    /** The longest lookback of the signals in this region, which sets the call's start time. */
    lookbackMinutes: number;
    /** How to turn each returned query into a reading, over its own lookback. */
    readings: Pick<StatusSignal, "id" | "periodSeconds" | "lookbackMinutes" | "reduce">[];
}
/**
 * The reads a run needs, one GetMetricData call per region, for the live components only. A signal
 * two components share, such as the Databricks check, is read once.
 */
export declare function statusQueries(config: StatusConfig): RegionQueries[];
export {};
//# sourceMappingURL=status-components.d.ts.map