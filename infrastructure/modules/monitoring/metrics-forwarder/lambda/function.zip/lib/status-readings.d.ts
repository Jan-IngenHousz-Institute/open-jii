import type { RegionQueries, StatusReadings } from "./status-components.js";
/** The parts of a GetMetricData result a reading needs, so the package needs no SDK. */
interface MetricDataResult {
    Id?: string;
    Timestamps?: Date[];
    Values?: number[];
}
type ReadingSpec = RegionQueries["readings"][number];
/**
 * Turns one region's GetMetricData results into readings, each over its own lookback. A signal
 * with no datapoint in its window has no reading, which the judge reads per signal: an absent
 * count is none, an absent heartbeat is a silent producer.
 */
export declare function collapseReadings(specs: ReadingSpec[], results: MetricDataResult[], now: Date): StatusReadings;
export {};
//# sourceMappingURL=status-readings.d.ts.map