import type { SlackMessage } from "./slack.js";
import type { Evaluation, MetricReading } from "./types.js";
export interface EvaluatedReading extends MetricReading {
    evaluation: Evaluation;
    /** A CloudWatch-rendered chart of this metric, when the composer produced one. */
    chartUrl?: string;
}
/**
 * A parent message and one reply per anomaly.
 *
 * The parent is the whole morning at a glance. Each reply carries the detail and the
 * links for one anomaly, so the channel stays one table however bad the day is and
 * nobody scrolls past nine buttons to reach the second problem.
 *
 * With no bot token the composer posts the parent alone, so the replies are additive
 * rather than a prerequisite.
 */
export interface Digest {
    parent: SlackMessage;
    replies: SlackMessage[];
}
export interface RenderOptions {
    environment: string;
    runbookBaseUrl?: string;
    /** Where the catalog entry lives, so a reader can change what a signal means. */
    catalogUrl?: string;
    /** CloudWatch console, for opening the query behind a reading. */
    consoleUrl?: string;
}
export declare function deltaGlyph(value: number, baseline: number | null, window: string): string;
/** Things that went wrong with the digest itself, as opposed to with the platform. */
export interface SelfChecks {
    configErrors: string[];
    failedRegions: string[];
}
export declare function renderObservability(readings: EvaluatedReading[], checks: SelfChecks, options: RenderOptions): Digest;
export declare function renderLevels(readings: MetricReading[], checks: SelfChecks, title: string, window: string, options: RenderOptions): Digest;
//# sourceMappingURL=render.d.ts.map