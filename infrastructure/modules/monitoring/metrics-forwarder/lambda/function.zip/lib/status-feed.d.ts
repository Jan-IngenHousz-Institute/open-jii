import { z } from "zod/mini";
import type { CachedStatusContent } from "./status-content.js";
export declare const STATUS_FEED_STATE_VERSION = 1;
/**
 * What the publisher carries beside its history. It is written only once the events are sent, so a
 * failed send leaves the old snapshot and the same events come up again on the next run.
 */
export declare const statusFeedStateSchema: z.ZodMiniObject<{
    version: z.ZodMiniLiteral<1>;
    announced: z.ZodMiniObject<{
        at: z.iso.ZodMiniISODateTime;
        incidents: z.ZodMiniArray<z.ZodMiniDiscriminatedUnion<[z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            kind: z.ZodMiniLiteral<"incident">;
            phase: z.ZodMiniEnum<{
                resolved: "resolved";
                open: "open";
            }>;
            updates: z.ZodMiniArray<z.ZodMiniString<string>>;
        }, z.core.$strip>, z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            kind: z.ZodMiniLiteral<"maintenance">;
            phase: z.ZodMiniEnum<{
                scheduled: "scheduled";
                "in-progress": "in-progress";
                completed: "completed";
            }>;
            updates: z.ZodMiniArray<z.ZodMiniString<string>>;
        }, z.core.$strip>], "kind">>;
        components: z.ZodMiniRecord<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }> & z.core.$partial, z.ZodMiniObject<{
            state: z.ZodMiniEnum<{
                operational: "operational";
                degraded: "degraded";
                outage: "outage";
                maintenance: "maintenance";
            }>;
            since: z.iso.ZodMiniISODateTime;
        }, z.core.$strip>>;
        notices: z.ZodMiniArray<z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            title: z.ZodMiniString<string>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    content: z.ZodMiniObject<{
        fetchedAt: z.iso.ZodMiniISODateTime;
        incidents: z.ZodMiniArray<z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            kind: z.ZodMiniEnum<{
                maintenance: "maintenance";
                incident: "incident";
            }>;
            title: z.ZodMiniString<string>;
            impact: z.ZodMiniEnum<{
                degraded: "degraded";
                outage: "outage";
            }>;
            components: z.ZodMiniArray<z.ZodMiniEnum<{
                platform: "platform";
                website: "website";
                "sign-in": "sign-in";
                "data-intake": "data-intake";
                "data-delivery": "data-delivery";
                "macro-processing": "macro-processing";
                exports: "exports";
            }>>;
            startsAt: z.iso.ZodMiniISODateTime;
            endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
            resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
            updates: z.ZodMiniArray<z.ZodMiniObject<{
                id: z.ZodMiniString<string>;
                stage: z.ZodMiniEnum<{
                    investigating: "investigating";
                    identified: "identified";
                    monitoring: "monitoring";
                    resolved: "resolved";
                    scheduled: "scheduled";
                    "in-progress": "in-progress";
                    completed: "completed";
                }>;
                postedAt: z.iso.ZodMiniISODateTime;
                text: z.ZodMiniString<string>;
                nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        notices: z.ZodMiniArray<z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            title: z.ZodMiniString<string>;
            body: z.ZodMiniString<string>;
            severity: z.ZodMiniEnum<{
                critical: "critical";
                warning: "warning";
                info: "info";
            }>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
}, z.core.$strip>;
export type StatusFeedState = z.infer<typeof statusFeedStateSchema>;
/**
 * The website shares the Contentful space's monthly API quota, and a read every minute from both
 * environments would use most of it.
 */
export declare const CONTENT_READ_MINUTES = 5;
/** How long the page may run on the cached incidents before a failed Contentful read fails the run. */
export declare const CONTENT_STALE_MINUTES = 15;
/**
 * Whether this run reads Contentful: once an interval has passed since the last good read and
 * since the last failed one, so a read that keeps failing, such as one for a content type that
 * does not exist yet, is not repeated every minute.
 */
export declare function isContentDue(cached: CachedStatusContent | undefined, lastFailedAt: Date | undefined, now: Date): boolean;
/**
 * What a failed Contentful read owes the errors alarm: nothing while the cached content is recent,
 * and past that, or with no cache, the reason the run fails once it has written everything.
 */
export declare function contentFailure(cause: string | undefined, cached: CachedStatusContent | undefined, now: Date): string | undefined;
//# sourceMappingURL=status-feed.d.ts.map