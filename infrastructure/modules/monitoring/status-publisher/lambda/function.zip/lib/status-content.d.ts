import { z } from "zod/mini";
import type { Incident, Notice } from "./status-document.js";
export declare const STATUS_CONTENT_LOCALE = "en-US";
export declare const STATUS_CONTENT_QUERY = "\nfragment StatusIncidentFields on StatusIncident {\n  sys {\n    id\n  }\n  title\n  kind\n  impact\n  components\n  startsAt\n  endsAt\n  resolvedAt\n  updatesCollection(limit: 20, locale: $locale) {\n    items {\n      sys {\n        id\n      }\n      stage\n      postedAt\n      text\n      nextUpdateBy\n    }\n  }\n}\n\nquery statusContent($now: DateTime!, $since: DateTime!, $locale: String!) {\n  open: statusIncidentCollection(\n    locale: $locale\n    limit: 50\n    order: [startsAt_DESC]\n    where: { resolvedAt_exists: false, startsAt_lte: $now }\n  ) {\n    items {\n      ...StatusIncidentFields\n    }\n  }\n  recent: statusIncidentCollection(\n    locale: $locale\n    limit: 100\n    order: [startsAt_DESC]\n    where: { startsAt_lte: $now, OR: [{ startsAt_gte: $since }, { resolvedAt_gte: $since }] }\n  ) {\n    items {\n      ...StatusIncidentFields\n    }\n  }\n  upcoming: statusIncidentCollection(\n    locale: $locale\n    limit: 50\n    order: [startsAt_ASC]\n    where: { kind: \"maintenance\", startsAt_gt: $now }\n  ) {\n    items {\n      ...StatusIncidentFields\n    }\n  }\n  notices: componentAlertCollection(\n    locale: $locale\n    limit: 20\n    where: {\n      active: true\n      audience: \"status\"\n      startAt_lte: $now\n      OR: [{ endAt_gt: $now }, { endAt_exists: false }]\n    }\n  ) {\n    items {\n      sys {\n        id\n      }\n      title\n      body {\n        json\n      }\n      severity\n    }\n  }\n}\n";
export interface StatusContentVariables {
    now: string;
    since: string;
    locale: string;
}
export declare function statusContentVariables(now: Date): StatusContentVariables;
/**
 * The `data` of Contentful's answer. A missing collection is an error rather than an empty one,
 * since an empty one would clear the incidents already on the page. Entries stay loose: one that
 * is half written is dropped when mapped, not here, so it cannot fail the whole read.
 */
export declare const statusContentResponseSchema: z.ZodMiniObject<{
    open: z.ZodMiniObject<{
        items: z.ZodMiniArray<z.ZodMiniNullable<z.ZodMiniObject<{
            sys: z.ZodMiniObject<{
                id: z.ZodMiniString<string>;
            }, z.core.$strip>;
            title: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            kind: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            impact: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            components: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniArray<z.ZodMiniString<string>>>>;
            startsAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            endsAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            resolvedAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            updatesCollection: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniObject<{
                items: z.ZodMiniArray<z.ZodMiniNullable<z.ZodMiniObject<{
                    sys: z.ZodMiniObject<{
                        id: z.ZodMiniString<string>;
                    }, z.core.$strip>;
                    stage: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                    postedAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                    text: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                    nextUpdateBy: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                }, z.core.$strip>>>;
            }, z.core.$strip>>>;
        }, z.core.$strip>>>;
    }, z.core.$strip>;
    recent: z.ZodMiniObject<{
        items: z.ZodMiniArray<z.ZodMiniNullable<z.ZodMiniObject<{
            sys: z.ZodMiniObject<{
                id: z.ZodMiniString<string>;
            }, z.core.$strip>;
            title: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            kind: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            impact: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            components: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniArray<z.ZodMiniString<string>>>>;
            startsAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            endsAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            resolvedAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            updatesCollection: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniObject<{
                items: z.ZodMiniArray<z.ZodMiniNullable<z.ZodMiniObject<{
                    sys: z.ZodMiniObject<{
                        id: z.ZodMiniString<string>;
                    }, z.core.$strip>;
                    stage: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                    postedAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                    text: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                    nextUpdateBy: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                }, z.core.$strip>>>;
            }, z.core.$strip>>>;
        }, z.core.$strip>>>;
    }, z.core.$strip>;
    upcoming: z.ZodMiniObject<{
        items: z.ZodMiniArray<z.ZodMiniNullable<z.ZodMiniObject<{
            sys: z.ZodMiniObject<{
                id: z.ZodMiniString<string>;
            }, z.core.$strip>;
            title: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            kind: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            impact: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            components: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniArray<z.ZodMiniString<string>>>>;
            startsAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            endsAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            resolvedAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            updatesCollection: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniObject<{
                items: z.ZodMiniArray<z.ZodMiniNullable<z.ZodMiniObject<{
                    sys: z.ZodMiniObject<{
                        id: z.ZodMiniString<string>;
                    }, z.core.$strip>;
                    stage: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                    postedAt: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                    text: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                    nextUpdateBy: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
                }, z.core.$strip>>>;
            }, z.core.$strip>>>;
        }, z.core.$strip>>>;
    }, z.core.$strip>;
    notices: z.ZodMiniObject<{
        items: z.ZodMiniArray<z.ZodMiniNullable<z.ZodMiniObject<{
            sys: z.ZodMiniObject<{
                id: z.ZodMiniString<string>;
            }, z.core.$strip>;
            title: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
            body: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniObject<{
                json: z.ZodMiniUnknown;
            }, z.core.$strip>>>;
            severity: z.ZodMiniOptional<z.ZodMiniNullable<z.ZodMiniString<string>>>;
        }, z.core.$strip>>>;
    }, z.core.$strip>;
}, z.core.$strip>;
export type StatusContentResponse = z.infer<typeof statusContentResponseSchema>;
/** Throws on any GraphQL error but an unresolvable link, since the data beside it may be partial. */
export declare function parseStatusContentResponse(body: unknown): StatusContentResponse;
export interface StatusContent {
    incidents: Incident[];
    notices: Notice[];
}
/** The last good read, kept so the page keeps its notes while Contentful is unreachable. */
export declare const cachedStatusContentSchema: z.ZodMiniObject<{
    fetchedAt: z.iso.ZodMiniISODateTime;
    incidents: z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        title: z.ZodMiniString<string>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        updates: z.ZodMiniArray<z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            stage: z.ZodMiniEnum<{
                investigating: "investigating";
                identified: "identified";
                monitoring: "monitoring";
                resolved: "resolved";
                scheduled: "scheduled";
                "in-progress": "in-progress";
                completed: "completed";
            }>;
            postedAt: z.iso.ZodMiniISODateTime;
            text: z.ZodMiniString<string>;
            nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    notices: z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        body: z.ZodMiniString<string>;
        severity: z.ZodMiniEnum<{
            critical: "critical";
            warning: "warning";
            info: "info";
        }>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type CachedStatusContent = z.infer<typeof cachedStatusContentSchema>;
/**
 * Maps what Contentful returned onto the document contract. An entry that does not satisfy it is
 * left out, and so is an update it links to, so a draft in progress cannot stop the publisher.
 * Incidents come oldest start first, updates newest first as the page shows them, and notices
 * most severe first.
 */
export declare function toStatusContent(response: StatusContentResponse): StatusContent;
//# sourceMappingURL=status-content.d.ts.map