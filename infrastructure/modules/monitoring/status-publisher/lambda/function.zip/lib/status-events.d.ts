import { z } from "zod/mini";
import type { StatusDocument } from "./status-document.js";
export declare const STATUS_EVENTS_VERSION = 1;
/** An incident or maintenance window as the document has it, without its updates. */
declare const incidentSummarySchema: z.ZodMiniObject<{
    id: z.ZodMiniString<string>;
    title: z.ZodMiniString<string>;
    kind: z.ZodMiniEnum<{
        maintenance: "maintenance";
        incident: "incident";
    }>;
    impact: z.ZodMiniEnum<{
        degraded: "degraded";
        outage: "outage";
    }>;
    components: z.ZodMiniArray<z.ZodMiniEnum<{
        platform: "platform";
        website: "website";
        "sign-in": "sign-in";
        "data-intake": "data-intake";
        "data-delivery": "data-delivery";
        "macro-processing": "macro-processing";
        exports: "exports";
    }>>;
    startsAt: z.iso.ZodMiniISODateTime;
    endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
}, z.core.$strip>;
export type IncidentSummary = z.infer<typeof incidentSummarySchema>;
export declare const statusEventSchema: z.ZodMiniDiscriminatedUnion<[z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"incident.opened">;
    incident: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>;
    update: z.ZodMiniOptional<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        stage: z.ZodMiniEnum<{
            investigating: "investigating";
            identified: "identified";
            monitoring: "monitoring";
            resolved: "resolved";
            scheduled: "scheduled";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        postedAt: z.iso.ZodMiniISODateTime;
        text: z.ZodMiniString<string>;
        nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>, z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"incident.updated">;
    incident: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>;
    update: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        stage: z.ZodMiniEnum<{
            investigating: "investigating";
            identified: "identified";
            monitoring: "monitoring";
            resolved: "resolved";
            scheduled: "scheduled";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        postedAt: z.iso.ZodMiniISODateTime;
        text: z.ZodMiniString<string>;
        nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>, z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"incident.resolved">;
    incident: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>;
    update: z.ZodMiniOptional<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        stage: z.ZodMiniEnum<{
            investigating: "investigating";
            identified: "identified";
            monitoring: "monitoring";
            resolved: "resolved";
            scheduled: "scheduled";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        postedAt: z.iso.ZodMiniISODateTime;
        text: z.ZodMiniString<string>;
        nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>, z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"maintenance.updated">;
    maintenance: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>;
    update: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        stage: z.ZodMiniEnum<{
            investigating: "investigating";
            identified: "identified";
            monitoring: "monitoring";
            resolved: "resolved";
            scheduled: "scheduled";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        postedAt: z.iso.ZodMiniISODateTime;
        text: z.ZodMiniString<string>;
        nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>, z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"maintenance.scheduled">;
    maintenance: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>;
    update: z.ZodMiniOptional<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        stage: z.ZodMiniEnum<{
            investigating: "investigating";
            identified: "identified";
            monitoring: "monitoring";
            resolved: "resolved";
            scheduled: "scheduled";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        postedAt: z.iso.ZodMiniISODateTime;
        text: z.ZodMiniString<string>;
        nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>, z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"maintenance.started">;
    maintenance: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>;
    update: z.ZodMiniOptional<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        stage: z.ZodMiniEnum<{
            investigating: "investigating";
            identified: "identified";
            monitoring: "monitoring";
            resolved: "resolved";
            scheduled: "scheduled";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        postedAt: z.iso.ZodMiniISODateTime;
        text: z.ZodMiniString<string>;
        nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>, z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"maintenance.completed">;
    maintenance: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        kind: z.ZodMiniEnum<{
            maintenance: "maintenance";
            incident: "incident";
        }>;
        impact: z.ZodMiniEnum<{
            degraded: "degraded";
            outage: "outage";
        }>;
        components: z.ZodMiniArray<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }>>;
        startsAt: z.iso.ZodMiniISODateTime;
        endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
        resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>;
    update: z.ZodMiniOptional<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        stage: z.ZodMiniEnum<{
            investigating: "investigating";
            identified: "identified";
            monitoring: "monitoring";
            resolved: "resolved";
            scheduled: "scheduled";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        postedAt: z.iso.ZodMiniISODateTime;
        text: z.ZodMiniString<string>;
        nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
    }, z.core.$strip>>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>, z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"component.changed">;
    component: z.ZodMiniEnum<{
        platform: "platform";
        website: "website";
        "sign-in": "sign-in";
        "data-intake": "data-intake";
        "data-delivery": "data-delivery";
        "macro-processing": "macro-processing";
        exports: "exports";
    }>;
    from: z.ZodMiniEnum<{
        operational: "operational";
        degraded: "degraded";
        outage: "outage";
        maintenance: "maintenance";
    }>;
    to: z.ZodMiniEnum<{
        operational: "operational";
        degraded: "degraded";
        outage: "outage";
        maintenance: "maintenance";
    }>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>, z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"notice.posted">;
    notice: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
        body: z.ZodMiniString<string>;
        severity: z.ZodMiniEnum<{
            critical: "critical";
            warning: "warning";
            info: "info";
        }>;
    }, z.core.$strip>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>, z.ZodMiniObject<{
    type: z.ZodMiniLiteral<"notice.removed">;
    notice: z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
    }, z.core.$strip>;
    version: z.ZodMiniLiteral<1>;
    id: z.ZodMiniString<string>;
    environment: z.ZodMiniString<string>;
    occurredAt: z.iso.ZodMiniISODateTime;
    pageUrl: z.ZodMiniURL;
}, z.core.$strip>], "type">;
export type StatusEvent = z.infer<typeof statusEventSchema>;
/** What subscribers were last told, which is all the next run needs to know what is new. */
export declare const announcedSchema: z.ZodMiniObject<{
    incidents: z.ZodMiniArray<z.ZodMiniDiscriminatedUnion<[z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        kind: z.ZodMiniLiteral<"incident">;
        phase: z.ZodMiniEnum<{
            resolved: "resolved";
            open: "open";
        }>;
        updates: z.ZodMiniArray<z.ZodMiniString<string>>;
    }, z.core.$strip>, z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        kind: z.ZodMiniLiteral<"maintenance">;
        phase: z.ZodMiniEnum<{
            scheduled: "scheduled";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        updates: z.ZodMiniArray<z.ZodMiniString<string>>;
    }, z.core.$strip>], "kind">>;
    components: z.ZodMiniRecord<z.ZodMiniEnum<{
        platform: "platform";
        website: "website";
        "sign-in": "sign-in";
        "data-intake": "data-intake";
        "data-delivery": "data-delivery";
        "macro-processing": "macro-processing";
        exports: "exports";
    }> & z.core.$partial, z.ZodMiniObject<{
        state: z.ZodMiniEnum<{
            operational: "operational";
            degraded: "degraded";
            outage: "outage";
            maintenance: "maintenance";
        }>;
        since: z.iso.ZodMiniISODateTime;
    }, z.core.$strip>>;
    notices: z.ZodMiniArray<z.ZodMiniObject<{
        id: z.ZodMiniString<string>;
        title: z.ZodMiniString<string>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type Announced = z.infer<typeof announcedSchema>;
export interface StatusEventsInput {
    /** Undefined on the first run, which only records a baseline. */
    previous: Announced | undefined;
    document: StatusDocument;
    environment: string;
    pageUrl: string;
    now: Date;
}
export interface StatusEventsResult {
    events: StatusEvent[];
    announced: Announced;
}
/**
 * The events a run owes subscribers, and the snapshot to keep once they are sent. The first run
 * only records a baseline, so what is already open never floods a channel. The snapshot always
 * takes the current state, so a change held back is not announced later. An update is told once by
 * its id, whatever is edited on it afterwards.
 */
export declare function statusEvents(input: StatusEventsInput): StatusEventsResult;
export {};
//# sourceMappingURL=status-events.d.ts.map