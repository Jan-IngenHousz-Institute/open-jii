import { z } from "zod/mini";
export declare const STATUS_FEED_STATE_VERSION = 1;
/**
 * What the publisher carries beside its history. It is written only once the events are sent, so a
 * failed send leaves the old snapshot and the same events come up again on the next run.
 */
export declare const statusFeedStateSchema: z.ZodMiniObject<{
    version: z.ZodMiniLiteral<1>;
    announced: z.ZodMiniObject<{
        incidents: z.ZodMiniArray<z.ZodMiniDiscriminatedUnion<[z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            kind: z.ZodMiniLiteral<"incident">;
            phase: z.ZodMiniEnum<{
                resolved: "resolved";
                open: "open";
            }>;
            updates: z.ZodMiniArray<z.ZodMiniString<string>>;
        }, z.core.$strip>, z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            kind: z.ZodMiniLiteral<"maintenance">;
            phase: z.ZodMiniEnum<{
                scheduled: "scheduled";
                "in-progress": "in-progress";
                completed: "completed";
            }>;
            updates: z.ZodMiniArray<z.ZodMiniString<string>>;
        }, z.core.$strip>], "kind">>;
        components: z.ZodMiniRecord<z.ZodMiniEnum<{
            platform: "platform";
            website: "website";
            "sign-in": "sign-in";
            "data-intake": "data-intake";
            "data-delivery": "data-delivery";
            "macro-processing": "macro-processing";
            exports: "exports";
        }> & z.core.$partial, z.ZodMiniObject<{
            state: z.ZodMiniEnum<{
                operational: "operational";
                degraded: "degraded";
                outage: "outage";
                maintenance: "maintenance";
            }>;
            since: z.iso.ZodMiniISODateTime;
        }, z.core.$strip>>;
        notices: z.ZodMiniArray<z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            title: z.ZodMiniString<string>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    content: z.ZodMiniOptional<z.ZodMiniObject<{
        fetchedAt: z.iso.ZodMiniISODateTime;
        incidents: z.ZodMiniArray<z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            kind: z.ZodMiniEnum<{
                maintenance: "maintenance";
                incident: "incident";
            }>;
            title: z.ZodMiniString<string>;
            impact: z.ZodMiniEnum<{
                degraded: "degraded";
                outage: "outage";
            }>;
            components: z.ZodMiniArray<z.ZodMiniEnum<{
                platform: "platform";
                website: "website";
                "sign-in": "sign-in";
                "data-intake": "data-intake";
                "data-delivery": "data-delivery";
                "macro-processing": "macro-processing";
                exports: "exports";
            }>>;
            startsAt: z.iso.ZodMiniISODateTime;
            endsAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
            resolvedAt: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
            updates: z.ZodMiniArray<z.ZodMiniObject<{
                id: z.ZodMiniString<string>;
                stage: z.ZodMiniEnum<{
                    investigating: "investigating";
                    identified: "identified";
                    monitoring: "monitoring";
                    resolved: "resolved";
                    scheduled: "scheduled";
                    "in-progress": "in-progress";
                    completed: "completed";
                }>;
                postedAt: z.iso.ZodMiniISODateTime;
                text: z.ZodMiniString<string>;
                nextUpdateBy: z.ZodMiniOptional<z.iso.ZodMiniISODateTime>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        notices: z.ZodMiniArray<z.ZodMiniObject<{
            id: z.ZodMiniString<string>;
            title: z.ZodMiniString<string>;
            body: z.ZodMiniString<string>;
            severity: z.ZodMiniEnum<{
                critical: "critical";
                warning: "warning";
                info: "info";
            }>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type StatusFeedState = z.infer<typeof statusFeedStateSchema>;
//# sourceMappingURL=status-feed.d.ts.map