const { createHash } = require('crypto');

exports.handler = async (event) => {
  const { request } = event.Records[0].cf;

  try {
    if (["POST","PUT","PATCH"].includes(request.method)) {
      const body = Buffer.from(request.body.data, request.body.encoding);
      const hash = createHash("sha256").update(body).digest("hex");
      request.headers["x-amz-content-sha256"] = [{ key:"x-amz-content-sha256", value:hash }];
      console.log('  computed hash:', hash);
    }
    return request;
  } catch (err) {
    console.error('edge_hash_body error:', err);
    throw err;
  }
};
